Ссылка на сайт:
https://dj-task-manager.onrender.com